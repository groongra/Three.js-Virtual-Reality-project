	
	/*Lucas Gonzalez de Alba 119112856 */
	
	var stats;
	var rendererStats;
	
	var clock;

	var container;
	var windowWidth = window.innerWidth;
	var windowHeight = window.innerHeight;
	
	var windowHalfX = window.innerWidth/2;
	var windowHalfY = window.innerHeight/2;
	
	var scene, renderer, camera, cameraControl ;
	
	var quadModel, model_1, model_2, model_3;
	
	var torusKnot, boxMaterialFlag, boxMesh0_direction, boxMesh0, boxMesh1_direction, boxMesh1, mesh1, mesh2, mesh3, mesh4, geometry2Scale;
	
	var lightShadowMapViewer;
	
	var shader0_material, shader1_material, shader2_material, vertexDisplacement;
	
	var SHADOW_MAP_WIDTH = 2048, SHADOW_MAP_HEIGHT = 1024;
	
	var delta, deltaClock;
	
	window.addEventListener( 'resize', onWindowResize, false );
	
	//initialization
	init();
		
	//render loop
	render();
	
	function init(){

		container = document.createElement('div');
		document.body.appendChild(container);
		
		//stats
		stats = new Stats();
        stats.showPanel( 0 ); // 0: fps, 1: ms, 2: mb, 3+: custom   
		document.body.appendChild( stats.dom );
		
		//RendererStats
		rendererStats = new THREEx.RendererStats();
		rendererStats.domElement.style.position   = 'absolute';
		rendererStats.domElement.style.left  = '0px';
		rendererStats.domElement.style.bottom    = '0px';
		document.body.appendChild( rendererStats.domElement );
		
		//Clock
		clock = new THREE.Clock();
		
		//Scene
		scene = new THREE.Scene();
		
		//renderer
		createRenderer();
		
		//camera
		createCamera();
		
		//axesHelper
		createAxesHelper();
		
		//Lights
		createLights();
		
		//create ground floor
		createPlane();
		
		//create film screen
		createBillboard();
		
		//Load Ucc quad collada model
		loadColladaModels();
		
		//Load model_1
		loadModel_1();
		
		//Load model_2
		loadModel_2();
		
		//Load 3D objects
		load_3D_Objects();
	}
	
		function loadModel_1(){
			
			var textureLoader = new THREE.TextureLoader( manager );

			var texture = textureLoader.load( 'assets/models/lego_figure/legoFace.png' );
			
			// > manager

			function loadModel() {

				model_1.traverse( function ( child ) {
				
					if ( child.isMesh ) {
						child.material.map = texture;
						child.castShadow = true;
					}
				} );
				
				model_1.castShadow = true;
				model_1.position.x = 5;
				model_1.position.z = 5;
				model_1.scale.set( 0.075, 0.075, 0.075 );
				scene.add( model_1 );

			}		
			
			var manager = new THREE.LoadingManager( loadModel );
			
			manager.onProgress = function ( item, loaded, total ) {
					console.log("OBJ legoMan loaded", item, loaded, total );
			};
			

			function onProgress( xhr ) {
				if ( xhr.lengthComputable ) {
					var percentComplete = xhr.loaded / xhr.total * 100;
					console.log( 'model ' + Math.round( percentComplete, 2 ) + '% downloaded' );
				}
			}
			
			function onError() {}

			loader_model_1 = new THREE.OBJLoader(manager);
			
			loader_model_1.load('assets/models/lego_figure/lego_obj.obj', function(obj){
					
					model_1 = obj;

			}, onprogress, onError);
		}

		function loadModel_2(){
			//Load model_2
			var mtLoader_model_2 = new THREE.MTLLoader();
			mtLoader_model_2.load("assets/models/mustang_obj/mustang_GT.mtl", function(texture){
				texture.preload();
				var objLoader = new THREE.OBJLoader();
				objLoader.setMaterials(texture);
				objLoader.load('assets/models/mustang_obj/mustang_GT.obj', function(mesh) {
					
					mesh.traverse(function(node){
						if(node instanceof THREE.Mesh){
							node.castShadow = true;
							node.receiveShadow = true;
						}
					});
					mesh.castShadow = true;				
					mesh.position.set(18,0,10);
					mesh.rotation.x =  - (Math.PI / 2);
					mesh.rotation.z = - (Math.PI / 4);
					mesh.scale.set( 0.1, 0.1, 0.1 );
					model_2 = mesh;
					scene.add(model_2);
				});
			});
		}
		
		function load_3D_Objects(){
			
			//Shader 0
			shader0_material = new THREE.ShaderMaterial({
				uniforms: {
					colour_dark : {type: "v4", value: new THREE.Vector4(0.5, 0.5, 1.0, 0.5)},
					temp: {type: "f", value: 1.0}
				},
				vertexShader: document.getElementById("vs0").textContent,
				fragmentShader: document.getElementById("fs0").textContent
			});

			//shader 1
			var customUniforms1 = {
				alpha: {value: 0}
			};
			
			shader1_material = new THREE.ShaderMaterial({
				uniforms: [],
				vertexShader: document.getElementById('vertexShader').textContent,
				fragmentShader: document.getElementById('fragmentShader').textContent
			});

			//shader 2
			var customUniforms2 = {
				delta: {value: 0}
			};
			
			shader2_material = new THREE.ShaderMaterial({
					uniforms: customUniforms2,
					vertexShader: document.getElementById('vertexShader2').textContent,
					fragmentShader: document.getElementById('fragmentShader2').textContent
				});

			boxMaterialFlag = 0;
			
			// Geometry
			var torusKnotGeometry = new THREE.TorusKnotBufferGeometry( 25, 8, 75, 20 );
			var torusKnotMaterial = new THREE.MeshPhongMaterial( {
				color: 0xff0000,
				shininess: 150,
				specular: 0x222222
			} );

			torusKnot = new THREE.Mesh( torusKnotGeometry, torusKnotMaterial );
			torusKnot.scale.multiplyScalar( 1 / 18 );
			torusKnot.position.set(-5,3,7);
			torusKnot.castShadow = true;
			torusKnot.receiveShadow = true;
			scene.add( torusKnot );
			
			//Geometry Box0	
			var geometry = new THREE.BoxGeometry( 5, 5, 5 );
			
			boxMesh0 = new THREE.Mesh( geometry, shader0_material);
			boxMesh0.castShadow = true;
			boxMesh0.position.set(30,2.5,-2.5);
			scene.add(boxMesh0);

			//Geometry Box1
			boxMesh1 = new THREE.Mesh( geometry, shader1_material );
			boxMesh1.castShadow = true;
			boxMesh1.position.set(30,2.5,2.5);
			scene.add(boxMesh1);
			
			//Geometry 1
			var geometry = new THREE.BoxBufferGeometry(100, 100, 100, 1,1,1);
			mesh1 = new THREE.Mesh(geometry, shader2_material);
			mesh1.reciveShadow = true;
			mesh1.position.set(30,10,0);
			mesh1.scale.set(0.05,0.05,0.05);
			scene.add(mesh1);
			
			//Geometry 1 attributes
			delta = 0;
			
			vertexDisplacement = new Float32Array(geometry.attributes.position.count);

				for (var i = 0; i < vertexDisplacement.length; i ++) {
					vertexDisplacement[i] = Math.sin(i);
				}

			geometry.addAttribute('vertexDisplacement', new THREE.BufferAttribute(vertexDisplacement, 1));

			geometry2Scale = 0;

			//Geometry2 Sphere0
			var geometry2 = new THREE.SphereGeometry(2.5, 50);
			mesh2 = new THREE.Mesh(geometry2, shader0_material);
			mesh2.castShadow = true;
			mesh2.geometry.center();
			mesh2.position.set(30,25,0);
			scene.add(mesh2);

			//Geometry2 Sphere1
			mesh3 = new THREE.Mesh(geometry2, shader2_material);  
			mesh3.castShadow = true;
			mesh3.position.set(30,-15,0)
			scene.add(mesh3);
			
			//Geometry 3
			var woodTexture = new THREE.TextureLoader().load( "assets/textures/wood.jpg" );
			woodTexture.wrapS = THREE.RepeatWrapping;
			woodTexture.wrapT = THREE.RepeatWrapping;
			woodTexture.repeat.set( 4, 4 );
			
			var material3 = new THREE.MeshPhongMaterial({ map: woodTexture });
			var geometry3 = new THREE.CircleGeometry( 10, 32 );
			mesh4 = new THREE.Mesh(geometry3, material3);
			mesh4.position.set(0,0.1,0);
			mesh4.rotation.x = -Math.PI / 2;

			scene.add(mesh4);
		}

		function createRenderer() {
			renderer = new THREE.WebGLRenderer();
			renderer.setPixelRatio( window.devicePixelRatio );
			renderer.setClearColor(0x000000, 1.0);
			renderer.setSize(window.innerWidth, window.innerHeight);
			renderer.shadowMap.enabled = true;
			renderer.shadowMap.type = THREE.BasicShadowMap;
			container.appendChild(renderer.domElement);
			
			console.log('Renderer created');
		}

		function createCamera() {
	
			camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000); //fov, aspect, near y far*/
			camera.position.x = 50;
			camera.position.y = 50;
			camera.position.z = 50;
			camera.lookAt(scene.position);
			cameraControl = new THREE.OrbitControls(camera,renderer.domElement);
			cameraControl.target.set( 0, 2, 0 );
			cameraControl.update();
			
			console.log('Camera created');
		}

		function createAxesHelper(){
			var axesHelper = new THREE.AxesHelper( 5 );
			scene.add( axesHelper );
		}	

		function createPlane(){
			var geometry = new THREE.PlaneGeometry( 200, 200, 32 );
			//geometry.normalsNeedUpdate = true;
			// load a texture, set wrap mode to repeat

			var material = new THREE.MeshPhongMaterial( {
				color: 0xa0adaf,
				shininess: 150,
				specular: 0x11111,
				side: THREE.DoubleSide} 
			);
			var plane = new THREE.Mesh( geometry, material );
			plane.rotation.x = Math.PI / 2;
			plane.rotation.Z = Math.PI / 4;
			plane.castShadow = false;
			plane.reciveShadow = true;
			scene.add( plane );
			
			console.log('Ground created');
		}

		function createBillboard(){
			var geometry = new THREE.PlaneGeometry( 20, 20, 5 );
			
			// load a texture, set wrap mode to repeat
			var video = document.getElementById( 'video' );

			var texture = new THREE.VideoTexture( video );
			texture.minFilter = THREE.LinearFilter;
			texture.magFilter = THREE.LinearFilter;
			texture.format = THREE.RGBFormat;
			
			var material = new THREE.MeshBasicMaterial( {
				//color: 0xB67E09,
				map: texture,
				side: THREE.DoubleSide} );
			var plane = new THREE.Mesh( geometry, material );
			plane.castShadow = true;
			plane.position.y = 10;
			scene.add( plane );
			
			console.log('Billboard created');
		}
		
		function loadColladaModels(){
			var loader = new THREE.ColladaLoader();
			loader.load('./assets/models/ucc_quad_model_dae/quad.dae',loadUccCollada);
			loader.load('./assets/models/carKitDae/ambulance.dae',loadAmbulanceCollada);
			
		}
		
		function loadUccCollada( collada ) {
			quadModel = loadCollada(collada);
			console.log('Collada ucc model loaded');
		}
		
		function loadAmbulanceCollada( collada ) {
			model_3 = loadCollada(collada);
			model_3.castShadow = true;
			console.log('Collada ambulance model loaded');
		}

		function loadCollada( collada ) {
			dae = collada.scene;
			dae.traverse( function ( child ) {
			
				if ( child.isMesh ) {
					child.castShadow = true;
				}
			});
			dae.castShadow = true;
			dae.reciveShadow = true;
			scene.add(dae);
			return dae;
		}

		function createLights() {
			
			var spotLight = new THREE.SpotLight(0xFCFF9D,0.5);
			spotLight.position.set(0,10,0);
			spotLight.shadowCameraNear = 5;
			spotLight.shadowCameraFar = 5;
			spotLight.castShadow = true;
			spotLight.shadowCameraVisible = true;
			spotLight.target.position.set( 0, 0, 0 );
			spotLight.shadow.mapSize.width = SHADOW_MAP_WIDTH;
			spotLight.shadow.mapSize.height = SHADOW_MAP_HEIGHT;
			scene.add(spotLight);
			
			// Spotlight shadow map
			/*var lightShadowMapViewer = new THREE.ShadowMapViewer( spotLight );
			lightShadowMapViewer.position.x = 10;
			lightShadowMapViewer.position.y = windowHeight - ( SHADOW_MAP_HEIGHT / 4 ) - 10;
			lightShadowMapViewer.size.width = SHADOW_MAP_WIDTH / 4;
			lightShadowMapViewer.size.height = SHADOW_MAP_HEIGHT / 4;
			lightShadowMapViewer.update();
			*/
			
			var spotLight2 = new THREE.SpotLight(0xFCFF9D,0.5);
			spotLight2.position.set(0, 100, -100);
			spotLight2.shadowCameraNear = 20;
			spotLight2.shadowCameraFar = 50;
			spotLight2.castShadow = true;
			spotLight2.shadowCameraVisible = true;
			spotLight2.target.position = new THREE.Object3D( 10, 20, 30 );
			spotLight2.shadow.mapSize.width = SHADOW_MAP_WIDTH;
			spotLight2.shadow.mapSize.height = SHADOW_MAP_HEIGHT;
			scene.add(spotLight2);
			
			
			
			var pointLight = new THREE.PointLight(0xFFF3FA,1);
			pointLight.castShadow = true;
			pointLight.shadowCameraVisible = true;
			pointLight.position.set(-100, 20, 0);
			pointLight.shadow.mapSize.width = SHADOW_MAP_WIDTH;
			pointLight.shadow.mapSize.height = SHADOW_MAP_HEIGHT;
			scene.add(pointLight);

			
			
			var directionalLight = new THREE.DirectionalLight( 0x404040 ); // soft white light
			directionalLight.castShadow = true;
			directionalLight.shadowCameraVisible = true;
			directionalLight.position.set(70, 20, -30);
			directionalLight.target.position.set( 0, 0, 0 );
			pointLight.shadow.mapSize.width = SHADOW_MAP_WIDTH;
			pointLight.shadow.mapSize.height = SHADOW_MAP_HEIGHT;
			scene.add( directionalLight );	

			
			
			var pointLight3 = new THREE.PointLight(0xffffff, 0.75);
			pointLight3.castShadow = true;
			pointLight3.shadowCameraVisible = true;
			pointLight3.position.set(100, 20, 100);
			pointLight3.shadow.mapSize.width = SHADOW_MAP_WIDTH;
			pointLight3.shadow.mapSize.height = SHADOW_MAP_HEIGHT;
			scene.add(pointLight3);

			
			
			//If you wish to locate the lights position and target uncomment the following linee:
			
			//addSpotLightHelper(spotLight);
			//addSpotLightHelper(spotLight2);
			//addPointLightHelper(pointLight);
			//addDirectionalLightHelper(directionalLight);
			//addPointLightHelper(pointLight3);
			
			console.log('Lights created');
		}

		function addSpotLightHelper(s){
			var spotLightHelper = new THREE.SpotLightHelper( s );
			scene.add( spotLightHelper );
		}

		function addPointLightHelper(s){
			var sphereSize = 1;
			var pointLightHelper = new THREE.PointLightHelper( s, sphereSize );
			scene.add( pointLightHelper );
		}

		function addDirectionalLightHelper(s){
			var directionalLightHelper = new THREE.DirectionalLightHelper( s, 5 );
			scene.add( directionalLightHelper );
		}
		
	function render() {

	animate();

		cameraControl.update();

		renderer.render(scene, camera);

		requestAnimationFrame(render);
	}

	function animate(){
		
		stats.begin();
		
		//Update deltas
		delta += 0.1;
		deltaClock = clock.getDelta();
		
		 //Update model_1 and model2 positions  
		if ( model_1 !== undefined ) {

			model_1.rotation.y -= deltaClock * 0.5;


		} if ( model_3 !== undefined ) {
			
			model_3.position.x = 15*Math.cos(delta);
			model_3.position.z = 15*Math.sin(delta);
			model_3.rotation.y = 10+Math.sin(delta);
		}			
		
		//Update shader_2 uniforms
		mesh1.material.uniforms.delta.value = 0.5 + Math.sin(delta) * 0.5;

		//Update shader_2 vertex displacement movement
		for (var i = 0; i < vertexDisplacement.length; i ++) {
			vertexDisplacement[i] = 0.5 + Math.sin(i + delta) * 0.25;
		}
		mesh1.geometry.attributes.vertexDisplacement.needsUpdate = true;
		
		//Update torusKnot rotation
		torusKnot.rotation.x += 0.25 * deltaClock;
		torusKnot.rotation.y += 2 * deltaClock;
		torusKnot.rotation.z += 1 * deltaClock;

		
		//Update mesh1 rotation
		mesh1.rotation.y += 0.1;
		
		//Update mesh2 and mesh3 scales
		if(geometry2Scale == Math.PI*2){
			geometry2Scale = 0;
		}
		geometry2Scale += 0.01;
		currentValue = Math.sin(geometry2Scale);
		mesh3.scale.set(currentValue,currentValue,currentValue);
		mesh2.scale.y = currentValue;
		
		//Update boxMesh0 and boxMesh1 positions
		if(boxMesh0.position.z== -2.5){
			boxMesh0_direction = -0.5;
			if(boxMaterialFlag==0) {
				boxMaterialFlag = 1;
				boxMesh0.material = shader0_material;
			} else {
				boxMaterialFlag = 0;
				boxMesh0.material = shader1_material;
			}
		}else if(boxMesh0.position.z == -20){
			boxMesh0_direction = +0.5;
		}
		if(boxMesh1.position.z== 2.5){
			boxMesh1_direction = +0.5;
			if(boxMaterialFlag==0) boxMesh1.material = shader0_material;                                                                                                 
			else boxMesh1.material = shader1_material;
		}
		else if(boxMesh1.position.z == 20){
			boxMesh1_direction = -0.5;
		}
		boxMesh0.position.z = boxMesh0.position.z + boxMesh0_direction;
		boxMesh1.position.z = boxMesh1.position.z + boxMesh1_direction;
		
		stats.end();
		stats.update();
		rendererStats.update(renderer);
	}

	function onWindowResize() {
		
		windowHalfX = window.innerWidth / 2;
		windowHalfY = window.innerHeight / 2;

		camera.aspect = window.innerWidth / window.innerHeight;
		camera.updateProjectionMatrix();

		renderer.setSize( window.innerWidth, window.innerHeight );
		
		console.log('Window resized');

	}






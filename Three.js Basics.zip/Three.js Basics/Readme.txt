
@author Lucas Gonzalez de Alba - 119112856 		https://cs1.ucc.ie/~lgda1/cs6105/assignment/index.html

This virtual reality scene is built using THREE.js main library with some auxiliary aid from external repositories.
The objective of the project was to represent a 3D scene using three's development tools. 
This meant understanding the structure of this web based technology (HyperText Markup Language, Cascading Style Sheets, Java Script, file organization...)
I decided to divide the structure into the following HTML and JS files:
 
 * The HTML file contains a very basic web organization.
   
   - Web tag layout (header, body, divs) to create the "canvas" on which the browser displays and renders the scene.
   
   - Script tags that link the Java script source code to the the HTML structures.
   
   - CSS link tag to provide very basic style design.
 
 * The JS files set up the scene and establish the behaviors of the elements contained in it.
   
   The script file is designed in two stages:
   
   - Initialization functionality
		function init()
		 
			º Set up scene: createRenderer(), createCamera(), createLights();
			º Set up scene elements: createPlane(), createBillboard();
			º Load/Create models: loadColladaModel(), loadModel_1(), loadModel_2(), load_3D_Objects();

   - Interaction functionality
   
		function render() 
			º function animate();
 
   Please note that additional functions have been created but most of them are commented because they only provide useful feedback during the development phase (example shadow-maps,axes-helpers and light-helpers)
 
In conclusion, although the end product doesn't provide aesthetics it does cover the expected functionalities the project requires. 
In addition, I would like to stress the complicated situation in which we many are due to the COVID-19 epidemic.
Fortunately my health hasn't been affected but the working conditions in which this assignment has taken place have. On one hand the only plausible way i found to develop this project was connecting remotely to UCC's server using ssh in my Linux virtual machine.
This not only caused many delays but also technical issues. On the other hand i lacked the previous lab resources like face-to-face discussions and feedback from lecturers.
For such reasons I apologize if the obtained results don't match the expected quality and hope that in following years students don't have to experience such issues. 


Special thanks to all contributors:

Libraries

  AxesHelper
 * @author sroucheray / http://sroucheray.org/
 * @author mrdoob / http://mrdoob.com/
  
  ColladaLoader
 * @author Mugen87 / https://github.com/Mugen87
 * @author mrdoob / http://mrdoob.com/
 
  MTTLoader
 * @author angelxuanchang

  OrbitControls
 * @author qiao / https://github.com/qiao
 * @author mrdoob / http://mrdoob.com
 * @author alteredq / http://alteredqualia.com/
 * @author WestLangley / http://github.com/WestLangley
 * @author erich666 / http://erichaines.com
 * @author ScieCode / http://github.com/sciecode
 
  ShadowMapViewer
 * @author arya-s / https://github.com/arya-s
 
  Stats
 * @author mrdoob / http://mrdoob.com/
 
  ThreeX.rendererStats
 * @author mrdoob / http://mrdoob.com/
 * @author jetienne / http://jetienne.com/
 
  VideoTexture
 * @author mrdoob / http://mrdoob.com/
 
  Shader
 * @author adobe / http://www.cjgammon.com
 
Assets

  Mustang
 * Created/distributed by Right Hemisphere, LTD (http://www.righthemisphere.com/)

  LegoMan
 * Created/distributed by 3ds Max Wavefront(c) 2007 guruware
 * Creation date: 18.05.2017 18:47:43
 
  CarKit
 * Created/distributed by Kenney (www.kenney.nl)
 * Creation date: 04-03-2020 23:39
 * License: (Creative Commons Zero, CC0)

Video
  THX
 * Created/distributed by thx (www.thx.com)